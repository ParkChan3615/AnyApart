package egovframework.example.board.vo;

public class BoardFormVO {
	
	private BoardVO boardVO;
	
	private BoardVO searchBoardVO;
	
	public BoardFormVO() {
		this.boardVO = new BoardVO();
		this.searchBoardVO = new BoardVO();
	}

	public BoardVO getBoardVO() {
		return boardVO;
	}

	public void setBoardVO(BoardVO boardVO) {
		this.boardVO = boardVO;
	}

	public BoardVO getSearchBoardVO() {
		return searchBoardVO;
	}

	public void setSearchBoardVO(BoardVO searchBoardVO) {
		this.searchBoardVO = searchBoardVO;
	}
	
	

}
