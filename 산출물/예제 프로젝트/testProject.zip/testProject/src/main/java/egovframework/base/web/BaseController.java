package egovframework.base.web;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.rte.fdl.property.EgovPropertyService;

public class BaseController {
	
	protected Logger logger = Logger.getLogger(this.getClass().getName());

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** Validator */
	@Resource(name = "beanValidator")
	protected DefaultBeanValidator beanValidator;
}
