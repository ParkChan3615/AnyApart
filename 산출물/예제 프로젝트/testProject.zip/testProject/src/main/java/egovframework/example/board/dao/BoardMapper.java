package egovframework.example.board.dao;

import java.util.List;

import egovframework.example.board.vo.BoardVO;
import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("boardMapper")
public interface BoardMapper {

	public List<BoardVO> selectSampleList(BoardVO searchVO) throws Exception;
	
	public int selectSampleListTotCnt(BoardVO searchVO) throws Exception;
	
}
