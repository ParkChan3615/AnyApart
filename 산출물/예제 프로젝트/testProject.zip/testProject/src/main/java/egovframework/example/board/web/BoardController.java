package egovframework.example.board.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.base.web.BaseController;
import egovframework.example.board.service.BoardService;
import egovframework.example.board.vo.BoardFormVO;
import egovframework.example.board.vo.BoardVO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;
@Controller
public class BoardController extends BaseController{
	
	@Resource(name = "boardService")
	private BoardService boardService;

	@RequestMapping(value = "/board/list.do")
	public String selectSampleList(BoardFormVO boardFormVO, ModelMap model) throws Exception {

		BoardVO searchBoardVO = boardFormVO.getSearchBoardVO();
				
		/** EgovPropertyService.sample */
		searchBoardVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchBoardVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing setting */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchBoardVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchBoardVO.getPageUnit());
		paginationInfo.setPageSize(searchBoardVO.getPageSize());

		searchBoardVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchBoardVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchBoardVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> sampleList = boardService.selectSampleList(searchBoardVO);
		model.addAttribute("resultList", sampleList);

		int totCnt = boardService.selectSampleListTotCnt(searchBoardVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "board/list";
	}
}
