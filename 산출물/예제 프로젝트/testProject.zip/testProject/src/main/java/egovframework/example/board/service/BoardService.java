package egovframework.example.board.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.base.service.BaseService;
import egovframework.example.board.dao.BoardMapper;
import egovframework.example.board.vo.BoardVO;

@Service("boardService")
public class BoardService extends BaseService{
	
	@Resource(name="boardMapper")
	private BoardMapper boardMapper;
	
	/**
	 * 글 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<BoardVO> selectSampleList(BoardVO searchVO) throws Exception {
		return boardMapper.selectSampleList(searchVO);
	}

	/**
	 * 글 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return 글 총 갯수
	 * @exception
	 */
	public int selectSampleListTotCnt(BoardVO searchVO) throws Exception {
		return boardMapper.selectSampleListTotCnt(searchVO);
	}

}
