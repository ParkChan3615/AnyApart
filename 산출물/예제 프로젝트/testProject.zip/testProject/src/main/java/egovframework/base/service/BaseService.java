package egovframework.base.service;

import org.apache.log4j.Logger;

public class BaseService {

	protected Logger logger = Logger.getLogger(this.getClass().getName());
}
