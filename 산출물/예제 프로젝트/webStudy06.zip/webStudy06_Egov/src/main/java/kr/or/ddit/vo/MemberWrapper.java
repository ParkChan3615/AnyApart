package kr.or.ddit.vo;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

public class MemberWrapper extends User{
	
	private static Collection<GrantedAuthority> makeAuthorities(List<String> authority){
		Set<GrantedAuthority> authorities = new HashSet<>();
		for(String role : authority) {
			authorities.add(new SimpleGrantedAuthority(role));
		}
		return authorities;
	}
	
	public MemberWrapper(MemberVO realMember) {
		super(realMember.getMem_id(), realMember.getMem_pass(), 
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				!"Y".equals(realMember.getMem_delete()),
				makeAuthorities(realMember.getAuthority()));
		this.realMember = realMember;
	}

	private MemberVO realMember;
	public MemberVO getRealMember() {
		return realMember;
	}
}
