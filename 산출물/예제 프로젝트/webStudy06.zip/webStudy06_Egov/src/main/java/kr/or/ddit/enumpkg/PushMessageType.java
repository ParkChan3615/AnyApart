package kr.or.ddit.enumpkg;

public enum PushMessageType {
	REGISTERED, REMOVED
}
