package kr.or.ddit.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;

public class CustomAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler{
	@Override
	protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
			throws IOException, ServletException {
		String saveId = request.getParameter("saveId");
		String mem_id = authentication.getName();
		Cookie idCookie = new Cookie("idCookie", mem_id);
		idCookie.setPath(request.getContextPath());
		int maxAge = 0;
		if(StringUtils.isNotBlank(saveId)) {
			maxAge = 60*60*24*7;
		}
		idCookie.setMaxAge(maxAge);
		response.addCookie(idCookie);
		super.handle(request, response, authentication);
	}
}





















