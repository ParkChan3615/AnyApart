package kr.or.ddit.guestbook.controller;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.or.ddit.enumpkg.ServiceResult;
import kr.or.ddit.guestbook.service.IGuestBookService;
import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.validate.groups.UpdateGroup;
import kr.or.ddit.vo.GuestBookVO;
import kr.or.ddit.vo.PagingVO;

@RestController
@RequestMapping(value="/book", produces=MediaType.APPLICATION_JSON_UTF8_VALUE)
public class GuestBookController {
	@Inject
	IGuestBookService service;
	
	@GetMapping
	public Map<String, Object> list(@RequestParam(required=false, name="page", defaultValue="1")  int currentPage ){
		Map<String, Object> resultMap = new HashMap<>();
		PagingVO<GuestBookVO> pagingVO = new PagingVO<>(5, 4);
		pagingVO.setCurrentPage(currentPage);
		pagingVO.setTotalRecord(service.retrieveGuestBookCount(pagingVO));
		pagingVO.setDataList(service.retrieveGuestBookList(pagingVO));
		resultMap.put("pagingVO", pagingVO);
		return resultMap;
	}
	
	@PostMapping(value="{gb_no}")
	public Object oneGuestBook(
			@PathVariable(required=true) int gb_no,
			@RequestParam(required=true) String gb_pass ){
		Object jsonTarget = null;
		GuestBookVO guestBook = service.retrieveGuestBook(new GuestBookVO(gb_no, gb_pass));
		if(guestBook!=null){
			jsonTarget = guestBook;
		}else{
			Map<String, Object> resultMap = new HashMap<>();
			resultMap.put("message", "비밀번호 오류");
			jsonTarget = resultMap;
		}
		return jsonTarget;		
	}
	
	@PostMapping
	public Map<String, Object> insert( @Validated(InsertGroup.class) GuestBookVO guestBook, Errors errors){
		Map<String, Object> resultMap = new HashMap<>();
		if(!errors.hasErrors()){
			ServiceResult result = service.createGuestBook(guestBook);
			if(ServiceResult.OK.equals(result)){
				resultMap.putAll(list(1));
			}else{
				resultMap.put("message", "방명록 등록 실패");
			}
		}else{
			resultMap.put("message", "누락 데이터 발생, 등록 실패");
		}
		return resultMap;
	}
	
	@PutMapping("{gb_no}")
	public Map<String, Object> update( @Validated(UpdateGroup.class) GuestBookVO guestBook, Errors errors){
		Map<String, Object> resultMap = new HashMap<>();
		if(!errors.hasErrors()){
			ServiceResult result = service.modifyGuestBook(guestBook);
			if(ServiceResult.OK.equals(result)){
				resultMap.putAll(list(1));
			}else{
				resultMap.put("message", "비밀번호 오류, 수정 실패");
			}
		}else{
			resultMap.put("message", "누락 데이터 발생, 수정 실패");
		}
		return resultMap;
	}
	
	@DeleteMapping(value="{gb_no}")
	public Map<String, Object> delete(
			@PathVariable(required=true) int gb_no,
			@RequestParam(required=true) String gb_pass){
		Map<String, Object> resultMap = new HashMap<>();
		ServiceResult result = service.removeGuestBook(new GuestBookVO(gb_no, gb_pass));
		if(ServiceResult.OK.equals(result)){
			resultMap.putAll(list(1));
		}else{
			resultMap.put("message", "비밀번호 오류, 삭제 실패");
		}
		return resultMap;
	}
}
