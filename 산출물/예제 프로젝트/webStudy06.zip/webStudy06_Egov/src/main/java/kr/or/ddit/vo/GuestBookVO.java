package kr.or.ddit.vo;

import java.io.IOException;
import java.util.Base64;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIgnore;

import kr.or.ddit.validate.groups.InsertGroup;
import kr.or.ddit.validate.groups.UpdateGroup;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@EqualsAndHashCode(of="gb_no")
public class GuestBookVO {
	public GuestBookVO(Integer gb_no, String gb_pass) {
		super();
		this.gb_no = gb_no;
		this.gb_pass = gb_pass;
	}
	@NotNull(groups=UpdateGroup.class) 
	@Min(0) 
	private Integer gb_no;
	@NotBlank
	@Size(max=30) 
	private String gb_writer;
	@NotBlank
	@Size(max=300) 
	private String gb_pass;
	@NotBlank(groups=InsertGroup.class)
	@Size(max=40, groups=InsertGroup.class) 
	private String gb_ip;
	@Size(max=200) 
	private String gb_content;
	private Integer gb_parent;
	private Integer gb_depth;
	@Size(max=7) 
	private String gb_date;
	@JsonIgnore
	private transient byte[] gb_profile;
	public String getGb_profileBase64(){
		String base64String = null;
		if(gb_profile!=null){
			base64String = Base64.getEncoder().encodeToString(gb_profile);
		}
		return base64String;
	}
	
	@JsonIgnore
	private MultipartFile gb_image;
	public void setGb_image(MultipartFile gb_image) throws IOException {
		this.gb_image = gb_image;
		if(gb_image!=null && !gb_image.isEmpty() 
				&& gb_image.getContentType().startsWith("image/")){
			gb_profile = gb_image.getBytes();
		}
	}
	@Size(max=1) 
	private String gb_secret;
}
