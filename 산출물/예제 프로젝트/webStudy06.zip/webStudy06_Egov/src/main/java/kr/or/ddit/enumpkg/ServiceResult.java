package kr.or.ddit.enumpkg;

public enum ServiceResult {
	OK, FAILED, NOTEXIST, INVALIDPASSWORD, PKDUPLICATED, DISABLE
}
