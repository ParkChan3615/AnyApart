package kr.or.ddit.commons.advice;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.dao.DataAccessException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.transaction.TransactionException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import egovframework.rte.fdl.cmmn.exception.EgovBizException;
import kr.or.ddit.CustomException;

/**
 * CustomException 을 발생하면, 404 상태 응답 전송
 *
 */
@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	
	@ExceptionHandler(CustomException.class)
	public String customExceptionHandler(CustomException e, Model model) {
		model.addAttribute("exception", e);
		return "errors/errorView";
	}
	
	@ExceptionHandler(DataAccessException.class)
	public String customExceptionHandler(DataAccessException e, Model model) {
		return "cmmn/dataAccessFailure";
	}
	@ExceptionHandler(TransactionException.class)
	public String customExceptionHandler(TransactionException e, Model model) {
		return "cmmn/transactionFailure";
	}
	@ExceptionHandler(EgovBizException.class)
	public String customExceptionHandler(EgovBizException e, Model model) {
		return "cmmn/egovError";
	}
	@ExceptionHandler(AccessDeniedException.class)
	public String customExceptionHandler(AccessDeniedException e, Model model) {
		return "cmmn/egovError";
	}
	

//	@ExceptionHandler(CustomException.class)
//	public void customExceptionHandler(CustomException e, HttpServletResponse resp) throws IOException {
//		resp.sendError(404, e.getMessage());
//	}
}





















