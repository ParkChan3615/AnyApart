package kr.or.ddit.guestbook.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import kr.or.ddit.vo.GuestBookVO;
import kr.or.ddit.vo.PagingVO;

/**
 * 방명록 관리를 위한 persistence layer
 * 작성,수정,조회(목록, 건수),삭제
 *
 */
@Repository
public interface IGuestBookDAO {
	public int insertGuestBook(GuestBookVO guestBook);
	public GuestBookVO selectGuestBook(GuestBookVO guestBook);
	public int selectGuestBookCount(PagingVO<GuestBookVO> pagingVO);
	public List<GuestBookVO> selectGuestBookList(PagingVO<GuestBookVO> pagingVO);
	public int updateGuestBook(GuestBookVO guestBook);
	public int deleteGuestBook(GuestBookVO guestBook);
}
