/**
 * 
 */
const GUESTBOOKURL = $.getContextPath()+"/book";
// 프로필 사진 태그 생성
function makeImgTag(guestBook){
	return $("<img>").attr({
				src:guestBook.gb_profileBase64?"data:image/*;base64,"+guestBook.gb_profileBase64
						:$.getContextPath()+"/images/noImage.png"										
			}).css({width:"50px",heigh:"50px", marginRight:"10px", marginLeft:"10px"});
}

// 방명록 한건의 UI 구성
function makeGBTable(guestBook){
	let table = $("<table class='w-100'>").prop("id", "GBTB_"+guestBook.gb_no)
									    .data("book", guestBook);
	let trUp = $("<tr>").append(
					$("<td class='col-3'>").append(
						makeImgTag(guestBook)									
						, $("<span>").text(guestBook.gb_writer)
					)
					,$("<td class='col-3'>").text(guestBook.gb_ip)
					,$("<td class='col-auto'>").text(guestBook.gb_date)
				);
	let trBottom = $("<tr>").append(
					$("<td colspan='2'>").text(guestBook.gb_content)
				);
	let lastTd = $("<td class='text-end col-3'>");
	if(!guestBook.nonSecret && guestBook.gb_secret == 'Y'){
		lastTd.append(
			$("<button class='btn btn-secondary secretBtn passwordBtn'>")
				.text("글보기")
				.data("formId", "passwordForm")	
				.data("method", "post")	
			, "&nbsp;" 
		);
	}else{
		lastTd.append(
				$("<button class='btn btn-primary updateBtn formBtn'>")
						.text("수정")
						.data("formId", "updateForm")	
						.data("method", "put")
				, "&nbsp;"
				, $("<button class='btn btn-danger deleteBtn passwordBtn'>")
						.text("삭제")
						.data("formId", "passwordForm")	
						.data("method", "delete")
				, "&nbsp;"
		);
		// 답글의 깊이 제한
		if(guestBook.gb_depth < 2){
			lastTd.append(
				$("<button class='btn btn-info replyBtn formBtn'>")
				.text("답글쓰기")
				.data("formId", "updateForm")	
				.data("method", "post")
			);
			
		}
	}
	
	trBottom.append(lastTd);
	table.append(trUp, trBottom);
	return table;
}
// 한페이지의 방명록 리스트 UI 구성
function modifyList(resultMap, renewFlag){
	let pagingVO = resultMap.pagingVO;
	if(pagingVO.dataList){
		let trTags = [];
		$(pagingVO.dataList).each(function(index, guestBook){
			let table = makeGBTable(guestBook);
			// 들여쓰기
			if(guestBook.gb_depth>1)
				table = [$("<h1>").text("┗>"), table]
			let trTag = $("<tr>").append(
							$("<td class='eachGBTag d-flex'>").append(table)
														   .data("gb_no", guestBook.gb_no)
						);
			trTags.push(trTag);
			
		});
		let remainRowCnt = pagingVO.screenSize - trTags.length;
  		for(let i=0; i<remainRowCnt; i++){
  			trTags.push($("<tr>").html($("<td colspan='3'>").html("&nbsp;")));
  		}
  		if(renewFlag=="success"){
  			listBody.append(trTags);
  		}else{
  			listBody.html(trTags);
  		}
		pagingArea.html(pagingVO.morePage);
		let scrollElement = listBody.parents("[class*='overflow']:first");
		scrollElement.animate({scrollTop:scrollElement.get(0).scrollHeight}, 1000);
	}
}
//전체 방명록 조회, 페이징 함수
function guestBookList(page){
	$.ajax({
		url:GUESTBOOKURL,
		method:"get",
		data:{
			page:page		
		},
		dataType:"json",
		success:modifyList,
		error:function(errorResp){
			console.log(errorResp.status);
		}
	});
}
// 방명록 첫 페이지 조회
guestBookList(1);
let pagingArea = $("#pagingArea");
let pagingA = pagingArea.on('click', "a" ,function(event){
	event.preventDefault();
	let page = $(this).data("page");
	guestBookList(page)
	return false;
}).on("click", ".scrollTop", function(event){
	$(this).parents("[class*='overflow']:first").animate({scrollTop:0}, 1000);
});

// 모달 내의 입력 태그에 대한 포커스 처리 및 폼 리셋
let modals = $("#passwordFormModal,#updateFormModal").on("shown.bs.modal", function(){
	$(this).find(":input[type!='hidden'][name]:first").focus();
}).on("hidden.bs.modal", function(){
	let form = $(this).find("form");
	form[0].reset();
	form.find("img").remove();
	form.attr("action", GUESTBOOKURL);
});

function bookUpdate(currentForm, currentBook){
	currentForm.attr("action", GUESTBOOKURL+"/"+currentBook.gb_no);
	currentForm.find(":input[name]").each(function(){
		if(this.name=="gb_pass") return true;
		else if(this.name=="gb_secret"){
			$(this).prop("checked", currentBook.gb_secret=='Y'?true:false);
		}else if(this.name=="gb_image"){
			$(this).before(makeImgTag(currentBook));
		}else{
			try{
				if(currentBook[this.name])
					$(this).val(currentBook[this.name]);
			}catch(e){
				return true;
			} 
		}
	});
}
function replyBook(currentForm, currentBook){
	currentForm.find("[name='gb_parent']").val(currentBook.gb_no);
	currentForm.find("[name='gb_depth']").val(currentBook.gb_depth+1);
}
function deleteBook(currentForm, currentBook){
	currentForm.attr("action", GUESTBOOKURL+"/"+currentBook.gb_no);
	if($(this).hasClass("secretBtn")){
		currentForm.find("[type='submit']").text("조회");
	}else{
		currentForm.find("[type='submit']").text("삭제");
	}
}
// 각 방명록 컨트롤 버튼 이벤트 처리
let listBody = $("#listBody").on("click", ".passwordBtn,.formBtn",function(){
	let currentBook = $(this).closest("table").data("book");
	let formId = $(this).data("formId");
	let _method = $(this).data("method");
	let currentForm = $("#"+formId);
	currentForm.find("[name='_method']").val(_method);
	
	if($(this).hasClass("updateBtn")){ // 수정
		bookUpdate(currentForm, currentBook);
	}else if($(this).hasClass("replyBtn")){ // 답글
		replyBook(currentForm, currentBook);
	}else if($(this).hasClass("passwordBtn")){ // 글삭제/비밀글 보기
		deleteBook(currentForm, currentBook);
	}
	
	$("#"+formId+"Modal").modal("show");
});

// 모든 폼에 대해 비동기 처리
let forms = $("#gbForm,#passwordForm,#updateForm").ajaxForm({
	dataType:"json",
	beforeSubmit: function(arr, $form, options) {
		for(let idx=arr.length-1; idx>=0; idx--){
			if(!arr[idx].value) arr.splice(idx, 1);
		}
	},
	success:successFunc,
	error:function(errorResp){
		console.log(errorResp.status);
	},
});

function successFunc(resp){
	if(resp.message){ // 실패
		alert(resp.message);
		return;
	}else if(resp.pagingVO){ // 목록 갱신
		$(forms).resetForm();
		$(modals).modal('hide');
		modifyList(resp);
	}else{ // 비밀글 조회
		$(modals).modal('hide');
		resp.nonSecret=true;
		var table = makeGBTable(resp);
		var td = $("#GBTB_"+resp.gb_no).parent();
		$("#GBTB_"+resp.gb_no).remove();
		td.html(table);
	}
}
	

	